package com.example.uas

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import com.squareup.picasso.Picasso

class fragment_thrid  // constructor for our list view adapter.
    (context: Context, dataModalArrayList: ArrayList<ElecModal?>?) :
    ArrayAdapter<ElecModal?>(context, 0, dataModalArrayList!!) {
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        // below line is use to inflate the
        // layout for our item of list view.
        var listitemView = convertView
        if (listitemView == null) {
            listitemView =
                LayoutInflater.from(context).inflate(R.layout.activity_fragment_thrid, parent, false)
        }

        // after inflating an item of listview item
        // we are getting data from array list inside
        // our modal class.
        val dataModal = getItem(position)

        // initializing our UI components of list view item.
        val nameTV = listitemView!!.findViewById<TextView>(R.id.idTVtext)
        val courseIV = listitemView.findViewById<ImageView>(R.id.idIVimage)

        // after initializing our items we are
        // setting data to our view.
        // below line is use to set data to our text view.
        nameTV.text = dataModal!!.name

        // in below line we are using Picasso to
        // load image from URL in our Image VIew.

        Picasso.get().load(dataModal.imgUrl).into(courseIV)

        // below line is use to add item click listener
        // for our item of list view.
        listitemView.setOnClickListener { // on the item click on our list view.
            // we are displaying a toast message.
            Toast.makeText(context, "Item clicked is : " + dataModal.name, Toast.LENGTH_SHORT)
                .show()
            val intent = Intent(context, Dataelec::class.java)
            intent.putExtra("name", dataModal.name)
            intent.putExtra("imgUrl", dataModal.imgUrl)
            context.startActivity(intent)
        }
        return listitemView
    }
}