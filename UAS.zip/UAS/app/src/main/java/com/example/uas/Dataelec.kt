package com.example.uas

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import com.squareup.picasso.Picasso

class Dataelec : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.dataelec)

        val back = findViewById<Button>(R.id.button3)
        back.setOnClickListener {
            val intent = Intent(applicationContext, SecondFragment::class.java)
            startActivity(intent)
            finish()
        }

        val intent = intent

        val datanama = intent.getStringExtra("name").toString()
        val nama = findViewById<TextView>(R.id.textView)
        nama.text = datanama

        val gambar = intent.getStringExtra("imgUrl").toString()
        val bingkai = findViewById<ImageView>(R.id.imageView)
        Picasso.get().load(gambar).into(bingkai)

    }
}